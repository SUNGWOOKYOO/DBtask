OS: Window 8.1 
Tool: Eclipse
Execution Plan: Please run hw#4

[Describtion]
Add Libraries of Hadoop
Set Run> Run Configuration> Arguments> "input_data result"
If it does not work, please execute eclipse as an adminstrator 